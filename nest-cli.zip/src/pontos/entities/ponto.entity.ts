export class Ponto {}
