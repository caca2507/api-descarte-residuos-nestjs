export class Registro {}
